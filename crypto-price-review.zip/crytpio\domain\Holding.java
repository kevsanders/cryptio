package com.sandkev.crytpio.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Version;

import java.math.BigDecimal;

@Entity
public class Holding {
    @Id
    @GeneratedValue
    Long id;
    String asset; BigDecimal quantity; BigDecimal avgCost; // in portfolio CCY
    @Version
    long version;

    public BigDecimal getQuantity() {
        return null;
    }

    public String getAsset() {
        return null;
    }

    public BigDecimal getAvgCost() {
        return quantity;
    }

    public void setAvgCost(BigDecimal avgCost) {
        this.quantity = avgCost;
    }
}
