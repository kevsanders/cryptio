package com.sandkev.crytpio;

import com.sandkev.crytpio.domain.TaxLot;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaxLotRepo extends JpaRepository<TaxLot, Long> {}