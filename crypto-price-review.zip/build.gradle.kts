//plugins {
//	java
//	id("org.springframework.boot") version "3.5.6"
//	id("io.spring.dependency-management") version "1.1.7"
//}
//
//group = "com.sandkev"
//version = "0.0.1-SNAPSHOT"
//description = "Demo project for Spring Boot"
//
//java {
//	toolchain {
//		languageVersion = JavaLanguageVersion.of(21)
//	}
//}
//
//repositories {
//	mavenCentral()
//}
//
//dependencies {
//	implementation("org.springframework.boot:spring-boot-starter")
//	testImplementation("org.springframework.boot:spring-boot-starter-test")
//	testRuntimeOnly("org.junit.platform:junit-platform-launcher")
//}
//
//tasks.withType<Test> {
//	useJUnitPlatform()
//}
// build.gradle.kts
plugins {
	id("java")
	id("org.springframework.boot") version "3.5.6"
	id("io.spring.dependency-management") version "1.1.7"
}

java { toolchain { languageVersion.set(JavaLanguageVersion.of(21)) } }
group = "com.sandkev.cryptio"
version = "0.0.1-SNAPSHOT"
description = "Manage Crypto Portfolio"

repositories { mavenCentral() }

dependencies {
	implementation("org.springframework.boot:spring-boot-starter-web")
	implementation("org.springframework.boot:spring-boot-starter-data-jpa")
	runtimeOnly("org.postgresql:postgresql:42.7.3")
	implementation("org.flywaydb:flyway-core:10.16.0")

	// XChange (choose only the exchanges you need)
	implementation("org.knowm.xchange:xchange-core:5.2.2")
	implementation("org.knowm.xchange:xchange-binance:5.2.2")
	implementation("org.knowm.xchange:xchange-coinbasepro:5.2.2")

	// Optional: ta4j
	implementation("org.ta4j:ta4j-core:0.16")

	// JSON + util
	implementation("com.fasterxml.jackson.core:jackson-databind:2.17.2")
	testImplementation("org.springframework.boot:spring-boot-starter-test")

	implementation("org.springframework.boot:spring-boot-starter-webflux") // WebClient
	implementation("com.github.ben-manes.caffeine:caffeine:3.1.8")         // in-memory cache
	implementation("io.github.resilience4j:resilience4j-spring-boot3:2.2.0")// retries/backoff
	testImplementation("org.springframework.boot:spring-boot-starter-test")

}
