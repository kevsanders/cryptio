package com.sandkev.crytpio.domain;

import jakarta.persistence.*;
import jakarta.transaction.Transactional;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
public class Transaction {
    @Id
    @GeneratedValue
    Long id;
    String exchange; String accountRef;
    String base; String quote; // e.g., BTC/USDT -> base=BTC, quote=USDT
    @Enumerated(EnumType.STRING)
    Transactional.TxType type;
    BigDecimal quantity; BigDecimal price; BigDecimal fee; String feeAsset;
    Instant ts; String externalId;
}