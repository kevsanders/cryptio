package com.sandkev.crytpio.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface HoldingRepo extends JpaRepository<Holding, Long> {}
