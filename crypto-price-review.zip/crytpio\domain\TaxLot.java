package com.sandkev.crytpio.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
public class TaxLot {
    @Id
    @GeneratedValue
    Long id;
    Asset asset; BigDecimal qtyOpen; BigDecimal costBasis; Instant openedAt;

    public TaxLot(Object o, Asset asset, BigDecimal qty, BigDecimal multiply, Instant ts) {

    }

    public Object getAsset() {
        return asset;
    }

    public void setAsset(Asset asset) {
        this.asset = asset;
    }

    public BigDecimal getQtyOpen() {
        return qtyOpen;
    }

    public void setQtyOpen(BigDecimal qtyOpen) {
        this.qtyOpen = qtyOpen;
    }

    public Instant getOpenedAt() {
        return openedAt;
    }

    public void setOpenedAt(Instant openedAt) {
        this.openedAt = openedAt;
    }
}