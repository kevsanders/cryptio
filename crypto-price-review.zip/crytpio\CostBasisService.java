package com.sandkev.crytpio;

import com.sandkev.crytpio.domain.Asset;
import com.sandkev.crytpio.domain.TaxLot;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Comparator;

@Service
public class CostBasisService {
    private final TaxLotRepo lots;

    public CostBasisService(TaxLotRepo lots) {
        this.lots = lots;
    }

    @Transactional
    public void applyTrade(Asset asset, BigDecimal qty, BigDecimal price, boolean isBuy, Instant ts) {
        if (isBuy) {
            TaxLot taxLot = new TaxLot(null, asset, qty, qty.multiply(price), ts);
            lots.save(taxLot);
            return;
        }

        // sell: deplete FIFO lots
        var remaining = qty;
        var fifo = lots.findAll().stream()
                .filter(l -> l.getAsset().equals(asset) && l.getQtyOpen().signum() > 0)
                .sorted(Comparator.comparing(TaxLot::getOpenedAt))
                .iterator();
        while (remaining.signum() > 0 && fifo.hasNext()) {
            var lot = fifo.next();
            var take = remaining.min(lot.getQtyOpen());
            lot.setQtyOpen(lot.getQtyOpen().subtract(take));
            lots.save(lot);
            remaining = remaining.subtract(take);
        }
        if (remaining.signum() > 0) throw new IllegalStateException("Short sell not supported");
    }
}



