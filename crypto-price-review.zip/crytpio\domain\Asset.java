package com.sandkev.crytpio.domain;

public record Asset(String symbol, String chain, String contract) {

}